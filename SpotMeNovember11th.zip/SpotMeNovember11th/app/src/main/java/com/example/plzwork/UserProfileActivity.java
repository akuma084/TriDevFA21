package com.example.plzwork;

import static android.content.ContentValues.TAG;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;


public class UserProfileActivity extends AppCompatActivity {
    TextView tvUserName; //Shows the current user's name pulled from their google account
    TextView tvUserEmail; //shows the current user's email
    ImageView userImageView; //shows the current user's profile picture
    Button btnSignOut; //signOut button (in progress I still need to make it so that the user can choose
    //which google account they want to log in with after signing out but it works for now)
    private FirebaseDatabase db = FirebaseDatabase.getInstance();//kai code
    private DatabaseReference root = db.getReference().child("Users");//kai code
    private DatabaseReference dataReference = db.getReference();//kai code
    private ListView mListView; //kai code

    FirebaseAuth mAuth = FirebaseAuth.getInstance();//get instance of the FirebaseAuth object
    FirebaseUser user = mAuth.getCurrentUser(); //Get the current user from the firebase API


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        HashMap<String, String> usermap = new HashMap<>(); //Puts the user's name and email into a
        //firebase database (can put other user attributes later)
        usermap.put("Name", user.getDisplayName());
        usermap.put("Email", user.getEmail());

        root.child(user.getUid()).setValue(usermap);//On firebase, all the user info is indexed by
        //their unique ID (UID)


        dataReference.addValueEventListener(new ValueEventListener() { //Kai code
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) { //Kai code
                showData(snapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { //Kai code

            }
        });


        tvUserName = findViewById(R.id.username); //Sets variables equal to the respective UI IDs
        tvUserEmail = findViewById(R.id.useremail);
        userImageView = findViewById(R.id.userImage);
        btnSignOut = findViewById(R.id.btnLogout);


        tvUserName.setText(user.getDisplayName()); //Displays the user's name and email
        tvUserEmail.setText(user.getEmail());
        Glide.with(this).load(user.getPhotoUrl()).into(userImageView); //Displays the user's profile picture


        btnSignOut.setOnClickListener(view ->{

            mAuth.signOut(); //Signs out and restarts the main activity



            startActivity(new Intent(UserProfileActivity.this, MainActivity.class));

        });


    }


    private void showData(DataSnapshot snapshot) { //Kai code
        for(DataSnapshot data:snapshot.getChildren()) {
            UserInfo arrayUser = new UserInfo();
            arrayUser.setName(data.child(user.getUid()).getValue(UserInfo.class).getName()); //Gets name and email of the user from Firebase
            arrayUser.setEmail(data.child(user.getUid()).getValue(UserInfo.class).getEmail());

            Log.d(TAG, "Name: " + arrayUser.getName());
            Log.d(TAG, "Email: " + arrayUser.getEmail());

            ArrayList<String> arr = new ArrayList<>();
            arr.add(arrayUser.getName()); //Puts the name and email into an array for each user in Firebase
            arr.add(arrayUser.getEmail());
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, arr);
            //mListView.setAdapter(adapter); This line makes the app crash, works fine without it. Not sure what the line does tbh
        }
    }


}