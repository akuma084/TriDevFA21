# SpotMe
This project is the implementation of the SpotMe android application
